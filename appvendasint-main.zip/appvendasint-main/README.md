# appvendasint
Curso python impressionador: 42. Criação de Aplicativo para Celular com kivy
